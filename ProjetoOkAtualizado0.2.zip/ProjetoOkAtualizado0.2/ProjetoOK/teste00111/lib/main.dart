import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'dart:io';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: TelaInicial(),
    );
  }
}

class TelaInicial extends StatelessWidget {
  const TelaInicial({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController controladorNome = TextEditingController();
    final TextEditingController controladorEmail = TextEditingController();
    final TextEditingController controladorSenha = TextEditingController();

    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Text(
                  'Bem-vindo Uniesper',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),
                TextField(
                  controller: controladorNome,
                  decoration: InputDecoration(
                    labelText: 'Nome',
                    labelStyle: const TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide: const BorderSide(color: Colors.white),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide: const BorderSide(color: Colors.white),
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.1),
                  ),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: controladorEmail,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    labelStyle: const TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide: const BorderSide(color: Colors.white),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide: const BorderSide(color: Colors.white),
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.1),
                  ),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: controladorSenha,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Senha',
                    labelStyle: const TextStyle(color: Colors.white),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide: const BorderSide(color: Colors.white),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide: const BorderSide(color: Colors.white),
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.1),
                  ),
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () {
                    if (controladorNome.text == 'Nome123' &&
                        controladorEmail.text == 'email123@exemplo.com' &&
                        controladorSenha.text == '123') {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const Hub()),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('Nome, email ou senha incorretos.')),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 50, vertical: 15),
                    backgroundColor: Colors.white,
                    foregroundColor: const Color.fromARGB(255, 255, 17, 0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  child: const Text(
                    'Login',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class Hub extends StatelessWidget {
  const Hub({super.key});

  @override
  Widget build(BuildContext context) {
    initializeDateFormatting('pt_BR', null);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        title: const Text(
          'Olá Uniesper',
          style: TextStyle(color: Colors.white),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 255, 0, 0),
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.help,
                  color: Color.fromARGB(255, 255, 17, 0)),
              title: const Text('Ajuda'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AjudaPag()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.schedule,
                  color: Color.fromARGB(255, 255, 17, 0)),
              title: const Text('Horários'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const HorariosPag()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.library_books,
                  color: Color.fromARGB(255, 255, 17, 0)),
              title: const Text('Biblioteca'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const BibliotecaPag()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.grade,
                  color: Color.fromARGB(255, 255, 17, 0)),
              title: const Text('Notas'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const NotasPag()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.school,
                  color: Color.fromARGB(255, 255, 17, 0)),
              title: const Text('Curso'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CursoPag()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.person,
                  color: Color.fromARGB(255, 255, 17, 0)),
              title: const Text('Perfil'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PerfilPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            TableCalendar(
              locale: 'pt_BR',
              firstDay: DateTime.utc(2020, 1, 1),
              lastDay: DateTime.utc(2030, 12, 31),
              focusedDay: DateTime.now(),
              selectedDayPredicate: (day) {
                return isSameDay(DateTime.now(), day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                // Lógica de seleção de dia
              },
              calendarFormat: CalendarFormat.month,
              startingDayOfWeek: StartingDayOfWeek.monday,
              headerStyle: const HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,
                titleTextStyle:
                    TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                leftChevronIcon: Icon(Icons.chevron_left, color: Colors.black),
                rightChevronIcon:
                    Icon(Icons.chevron_right, color: Colors.black),
              ),
              calendarStyle: const CalendarStyle(
                todayDecoration: BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
                selectedDecoration: BoxDecoration(
                  color: Colors.redAccent,
                  shape: BoxShape.circle,
                ),
                weekendTextStyle: TextStyle(color: Colors.red),
                defaultTextStyle: TextStyle(color: Colors.black),
              ),
              daysOfWeekStyle: const DaysOfWeekStyle(
                weekdayStyle: TextStyle(color: Colors.black),
                weekendStyle: TextStyle(color: Colors.red),
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 255, 17, 0),
                  borderRadius: BorderRadius.circular(16.0),
                ),
                padding: const EdgeInsets.all(16.0),
                child: const Column(
                  children: [
                    Text(
                      'Feriados e Datas',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Confraternização Universal: 1 de Janeiro\n'
                      'Carnaval: Data variável\n'
                      'Sexta-feira Santa: Data variável\n'
                      'Tiradentes: 21 de Abril\n'
                      'Dia do Trabalho: 1 de Maio\n'
                      'Corpus Christi: Data variável\n'
                      'Independência do Brasil: 7 de Setembro\n'
                      'Nossa Senhora Aparecida: 12 de Outubro\n'
                      'Finados: 2 de Novembro\n'
                      'Proclamação da República: 15 de Novembro\n'
                      'Natal: 25 de Dezembro',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PerfilPage extends StatefulWidget {
  const PerfilPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _PerfilPageState createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {
  String _name = 'Nome123';
  String _email = 'email123@exemplo.com';
  XFile? _image;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: _image != null
                  ? FileImage(File(_image!.path))
                  : const NetworkImage('https://via.placeholder.com/150')
                      as ImageProvider,
            ),
            const SizedBox(height: 20),
            Text(
              _name,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              _email,
              style: const TextStyle(fontSize: 18, color: Colors.grey),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => EditPerfilPage(
                            name: _name,
                            email: _email,
                            image: _image,
                          )),
                );
                if (result != null && result is Map<String, dynamic>) {
                  setState(() {
                    _name = result['name'];
                    _email = result['email'];
                    _image = result['image'];
                  });
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 255, 17, 0),
              ),
              child: const Text(
                'Editar Perfil',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class EditPerfilPage extends StatefulWidget {
  final String name;
  final String email;
  final XFile? image;

  const EditPerfilPage({
    super.key,
    required this.name,
    required this.email,
    this.image,
  });

  @override
  // ignore: library_private_types_in_public_api
  _EditPerfilPageState createState() => _EditPerfilPageState();
}

class _EditPerfilPageState extends State<EditPerfilPage> {
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  XFile? _image;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.name);
    _emailController = TextEditingController(text: widget.email);
    _image = widget.image;
  }

  Future<void> _pickImage() async {
    try {
      final picker = ImagePicker();
      final pickedImage = await picker.pickImage(source: ImageSource.gallery);
      if (pickedImage != null) {
        setState(() {
          _image = pickedImage;
        });
      }
    } catch (e) {
      if (kDebugMode) {
        print("Erro ao selecionar a imagem: $e");
      }
    }
  }

  Future<void> _takePhoto() async {
    try {
      final picker = ImagePicker();
      final pickedImage = await picker.pickImage(source: ImageSource.camera);
      if (pickedImage != null) {
        setState(() {
          _image = pickedImage;
        });
      }
    } catch (e) {
      if (kDebugMode) {
        print("Erro ao tirar a foto: $e");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Editar Perfil'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Nome'),
            ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            const SizedBox(height: 20),
            _image == null
                ? const Text('Nenhuma imagem selecionada.')
                : Image.file(File(_image!.path)),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: _pickImage,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 17, 0),
                  ),
                  child: const Text(
                    'Selecionar Imagem',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _takePhoto,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 17, 0),
                  ),
                  child: const Text(
                    'Tirar Foto',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, {
                  'name': _nameController.text,
                  'email': _emailController.text,
                  'image': _image,
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 255, 17, 0),
              ),
              child: const Text(
                'Salvar',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AjudaPag extends StatelessWidget {
  const AjudaPag({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ajuda'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ListTile(
            leading: const Icon(Icons.school,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Matrícula',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Informações sobre como realizar a matrícula na faculdade.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text('Matrícula Predefinida'),
                    content: const Text(
                        'Curso: Sistemas para Internet\nMatrícula: XXXX1234'),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: const Text('Fechar'),
                      ),
                    ],
                  );
                },
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.access_time,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Envio de Horas Extras',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Como enviar e registrar suas horas extras.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const EnvioHorasExtrasPag()),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.question_answer,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Questões da Faculdade',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Respostas para as perguntas mais frequentes dos alunos.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {},
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.contact_phone,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Entrar em Contato',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Informações de contato para suporte adicional.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const EntrarContatoPag()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class EnvioHorasExtrasPag extends StatelessWidget {
  const EnvioHorasExtrasPag({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Envio de Horas Extras'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const ListTile(
            leading:
                Icon(Icons.access_time, color: Color.fromARGB(255, 255, 17, 0)),
            title: Text(
              'Envio de Horas Extras',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              'Para registrar e enviar suas horas extras, envie um email para o endereço abaixo.',
              style: TextStyle(fontSize: 16),
            ),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Envie suas horas extras para este email:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 10),
          const Center(
            child: Text(
              'testehorasextras@uniesp.com',
              style: TextStyle(
                  fontSize: 18,
                  color: Color.fromARGB(255, 255, 17, 0),
                  fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 20),
          ListTile(
            leading: const Icon(Icons.help_outline,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Ajuda',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Caso precise de ajuda adicional, entre em contato com a faculdade.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}

class EntrarContatoPag extends StatelessWidget {
  const EntrarContatoPag({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Entrar em Contato'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const ListTile(
            leading: Icon(Icons.contact_phone,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: Text(
              'Entrar em Contato',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              'Para suporte adicional, entre em contato pelo número abaixo.',
              style: TextStyle(fontSize: 16),
            ),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Telefone para contato:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 10),
          const Center(
            child: Text(
              '(99) 99999-9999',
              style: TextStyle(
                  fontSize: 18,
                  color: Color.fromARGB(255, 255, 17, 0),
                  fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 20),
          ListTile(
            leading: const Icon(Icons.help_outline,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Ajuda',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Caso precise de ajuda adicional, entre em contato com a faculdade.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}

class HorariosPag extends StatelessWidget {
  const HorariosPag({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Horários'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: Center(
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const <DataColumn>[
              DataColumn(label: Text('Horário')),
              DataColumn(label: Text('Segunda')),
              DataColumn(label: Text('Terça')),
              DataColumn(label: Text('Quarta')),
              DataColumn(label: Text('Quinta')),
              DataColumn(label: Text('Sexta')),
            ],
            rows: List.generate(
              6,
              (index) => DataRow(
                cells: List.generate(
                  6,
                  (cellIndex) => DataCell(
                    GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              title: const Text('Detalhes da Aula'),
                              content: const Text('Informações da aula...'),
                              actions: <Widget>[
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: const Text('Fechar'),
                                ),
                              ],
                            );
                          },
                        );
                      },
                      child: const Text('Aula'),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class BibliotecaPag extends StatelessWidget {
  const BibliotecaPag({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Biblioteca'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: const BibliotecaCorpo(),
    );
  }
}

class BibliotecaCorpo extends StatelessWidget {
  const BibliotecaCorpo({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          const Calendario(),
          const SizedBox(height: 20),
          const Text(
            'Livros Disponíveis para Aluguel',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const LivrosDisponiveis(),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const BibliotecaOnlinePag()),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color.fromARGB(255, 255, 17, 0),
              foregroundColor: Colors.white,
            ),
            child: const Text('Biblioteca Online'),
          ),
        ],
      ),
    );
  }
}

class Calendario extends StatelessWidget {
  const Calendario({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: initializeDateFormatting('pt_BR', null),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          return TableCalendar(
            locale: 'pt_BR',
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            focusedDay: DateTime.now(),
            selectedDayPredicate: (day) {
              return isSameDay(DateTime.now(), day);
            },
            onDaySelected: (selectedDay, focusedDay) {
              // Lógica de seleção de dia
            },
            calendarFormat: CalendarFormat.month,
            startingDayOfWeek: StartingDayOfWeek.monday,
            headerStyle: const HeaderStyle(
              formatButtonVisible: false,
              titleCentered: true,
              titleTextStyle:
                  TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              leftChevronIcon: Icon(Icons.chevron_left, color: Colors.black),
              rightChevronIcon: Icon(Icons.chevron_right, color: Colors.black),
            ),
            calendarStyle: const CalendarStyle(
              todayDecoration: BoxDecoration(
                color: Colors.red,
                shape: BoxShape.circle,
              ),
              selectedDecoration: BoxDecoration(
                color: Colors.redAccent,
                shape: BoxShape.circle,
              ),
              weekendTextStyle: TextStyle(color: Colors.red),
              defaultTextStyle: TextStyle(color: Colors.black),
            ),
            daysOfWeekStyle: const DaysOfWeekStyle(
              weekdayStyle: TextStyle(color: Colors.black),
              weekendStyle: TextStyle(color: Colors.red),
            ),
          );
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      },
    );
  }
}

class LivrosDisponiveis extends StatelessWidget {
  const LivrosDisponiveis({super.key});

  final List<String> _livros = const [
    'Livro 1',
    'Livro 2',
    'Livro 3',
  ];

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
        itemCount: _livros.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(_livros[index]),
            trailing: ElevatedButton(
              onPressed: () {
                final dataDevolucao =
                    DateTime.now().add(const Duration(days: 14));
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Aluguel Confirmado'),
                    content: Text(
                        'Você alugou "${_livros[index]}". Devolução em ${dataDevolucao.day}/${dataDevolucao.month}/${dataDevolucao.year}.'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('OK'),
                      ),
                    ],
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 255, 17, 0),
                foregroundColor: Colors.white,
              ),
              child: const Text('Confirmar o Aluguel'),
            ),
          );
        },
      ),
    );
  }
}

class BibliotecaOnlinePag extends StatelessWidget {
  const BibliotecaOnlinePag({super.key});

  final List<String> _livrosDigitais = const [
    'Livro Digital 1',
    'Livro Digital 2',
    'Livro Digital 3',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Biblioteca Online'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: ListView.builder(
        itemCount: _livrosDigitais.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(_livrosDigitais[index]),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        DetalheLivroPag(titulo: _livrosDigitais[index])),
              );
            },
          );
        },
      ),
    );
  }
}

class DetalheLivroPag extends StatelessWidget {
  final String titulo;

  const DetalheLivroPag({required this.titulo, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(titulo),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: const Center(
        child: Text(
          'Olá, Uniesper!',
          style: TextStyle(fontSize: 18),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class NotasPag extends StatelessWidget {
  const NotasPag({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notas'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: Center(
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const <DataColumn>[
              DataColumn(label: Text('Matéria')),
              DataColumn(label: Text('Nota')),
            ],
            rows: const <DataRow>[
              DataRow(
                cells: <DataCell>[
                  DataCell(Text('Programação Web')),
                  DataCell(Text('8.5')),
                ],
              ),
              DataRow(
                cells: <DataCell>[
                  DataCell(Text('Banco de Dados')),
                  DataCell(Text('9.0')),
                ],
              ),
              DataRow(
                cells: <DataCell>[
                  DataCell(Text('Desenvolvimento de Aplicações')),
                  DataCell(Text('8.2')),
                ],
              ),
              DataRow(
                cells: <DataCell>[
                  DataCell(Text('Design de Interfaces')),
                  DataCell(Text('8.7')),
                ],
              ),
              DataRow(
                cells: <DataCell>[
                  DataCell(Text('Redes de Computadores')),
                  DataCell(Text('8.9')),
                ],
              ),
              DataRow(
                cells: <DataCell>[
                  DataCell(Text('Projeto Integrador')),
                  DataCell(Text('9.5')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CursoPag extends StatelessWidget {
  const CursoPag({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Curso'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ListTile(
            leading: const Icon(Icons.computer,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Sistemas pra internet',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre desenvolvimento e gestão de sistemas de informação.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SistemasPage()),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading:
                const Icon(Icons.code, color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Engenharia de Software',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre desenvolvimento de software e aplicativos.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              // Ação ao tocar na lista
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.storage,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Tecnologia da Informação',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre infraestrutura de TI e gerenciamento de dados.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              // Ação ao tocar na lista
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.local_hospital,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Medicina',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre ciências médicas e práticas clínicas.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              // Ação ao tocar na lista
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.health_and_safety,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Odontologia',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre saúde bucal e práticas odontológicas.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {},
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.accessibility_new,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Fisioterapia',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre reabilitação física e práticas fisioterapêuticas.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {},
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.translate,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Tradução e Interpretação',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre técnicas de tradução e interpretação de idiomas.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {},
          ),
          const Divider(),
          ListTile(
            leading:
                const Icon(Icons.book, color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Letras',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre linguística, literatura e ensino de línguas.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              // Ação ao tocar na lista
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.medical_services,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Enfermagem',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre cuidados com a saúde e práticas de enfermagem.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              // Ação ao tocar na lista
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.restaurant_menu,
                color: Color.fromARGB(255, 255, 17, 0)),
            title: const Text(
              'Nutrição',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text(
              'Curso sobre alimentação, nutrição e saúde.',
              style: TextStyle(fontSize: 16),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            onTap: () {
              // Ação ao tocar na lista
            },
          ),
        ],
      ),
    );
  }
}

class SistemasPage extends StatelessWidget {
  const SistemasPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sistemas pra Internet'),
        backgroundColor: const Color.fromARGB(255, 255, 17, 0),
      ),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sistemas pra Internet',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Text(
              'Descrição do curso:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'Este curso oferece uma formação abrangente em desenvolvimento e gestão de sistemas de informação, preparando os alunos para uma carreira em TI com foco em tecnologias web.',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Duração:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              '2 anos e meio',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Grade curricular:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              '• Introdução a Programação\n• Desenvolvimento Web\n• Banco de Dados\n• Engenharia de Software\n• Redes de Computadores\n• Segurança da Informação\n• Estágio Supervisionado\n• Trabalho de Conclusão de Curso (TCC)',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
